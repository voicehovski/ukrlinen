<?php
/**
 * @package     Joomla.Administrator
 * @subpackage  com_orangeei
 *
 * @copyright   Copyright (C) 2005 - 2015 Open Source Matters, Inc. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */
// No direct access to this file
defined('_JEXEC') or die('Restricted access');
 
class OrangeEIControllerOrangeImportResult extends JControllerForm
{
	public function display ( $cachable = false, $urlparams = false ) {
		
		$input = JFactory::getApplication()->input;
		$input->set('view', 'orangeimportresult');
		parent::display ( $cachable, $safeurlparams );
		return $this;
	}
}